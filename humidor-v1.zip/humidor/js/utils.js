// utils.js — Petites fonctions pures réutilisées par les écrans.

export function formatPrice(value, currency = 'EUR') {
  if (value == null || isNaN(value)) return '—';
  const symbols = { EUR: '€', USD: '$', GBP: '£' };
  const symbol = symbols[currency] || currency;
  return `${Number(value).toFixed(2).replace('.00', '')} ${symbol}`;
}

export function formatDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function formatDateTime(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

// Calcule l'âge (temps passé dans l'humidor) en années / mois à partir
// d'une date d'entrée ISO (YYYY-MM-DD).
export function computeAge(entryDateISO) {
  if (!entryDateISO) return null;
  const entry = new Date(entryDateISO);
  if (isNaN(entry.getTime())) return null;
  const now = new Date();
  let months = (now.getFullYear() - entry.getFullYear()) * 12 + (now.getMonth() - entry.getMonth());
  if (now.getDate() < entry.getDate()) months -= 1;
  months = Math.max(0, months);
  const years = Math.floor(months / 12);
  const remMonths = months % 12;
  if (years === 0 && remMonths === 0) return "Moins d'un mois";
  if (years === 0) return `${remMonths} mois`;
  if (remMonths === 0) return `${years} an${years > 1 ? 's' : ''}`;
  return `${years} an${years > 1 ? 's' : ''} ${remMonths} mois`;
}

export function cigarValue(cigar) {
  const unit = cigar.purchasePrice != null ? cigar.purchasePrice : 0;
  return unit * (cigar.quantity || 0);
}

export function collectionValue(cigars) {
  return cigars.reduce((sum, c) => sum + cigarValue(c), 0);
}

export function totalCigarCount(cigars) {
  return cigars.reduce((sum, c) => sum + (c.quantity || 0), 0);
}

export function countryFlag(country) {
  const flags = {
    Cuba: '🇨🇺', 'République dominicaine': '🇩🇴', Nicaragua: '🇳🇮',
    Honduras: '🇭🇳', Mexique: '🇲🇽', 'États-Unis': '🇺🇸', Brésil: '🇧🇷',
    Équateur: '🇪🇨', Espagne: '🇪🇸', Panama: '🇵🇦',
  };
  return flags[country] || '🌎';
}

export function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function initials(str) {
  if (!str) return '?';
  return str.trim().slice(0, 1).toUpperCase();
}
