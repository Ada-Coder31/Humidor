// storage.js — Couche de persistance locale (localStorage).
// Toutes les données de l'app passent par ce module : aucune autre partie
// du code ne doit toucher localStorage directement. Ça isole le "comment
// c'est stocké" du "comment c'est utilisé", pour pouvoir migrer plus tard
// vers une base distante sans toucher le reste de l'app.

const DB_KEY = 'humidor.db.v1';

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function nowISO() {
  return new Date().toISOString();
}

function defaultDB() {
  return {
    version: 1,
    settings: {
      currency: 'EUR',
      defaultHumidorId: 'humidor-1',
    },
    humidors: [
      { id: 'humidor-1', name: 'Mon humidor', capacity: 100, targetHumidity: null, targetTemperature: null },
    ],
    cigars: [],
    movements: [],
    tastings: [],
  };
}

function loadDB() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) {
      const fresh = defaultDB();
      saveDB(fresh);
      return fresh;
    }
    const parsed = JSON.parse(raw);
    // Filet de sécurité si une future version ajoute des champs.
    return { ...defaultDB(), ...parsed };
  } catch (e) {
    console.error('Erreur de lecture du stockage local, réinitialisation.', e);
    const fresh = defaultDB();
    saveDB(fresh);
    return fresh;
  }
}

function saveDB(db) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

let db = loadDB();

function persist() {
  saveDB(db);
}

// ---------------------------------------------------------------------
// Cigares
// ---------------------------------------------------------------------

function getCigars() {
  return db.cigars;
}

function getCigar(id) {
  return db.cigars.find((c) => c.id === id) || null;
}

function addCigar(data) {
  const cigar = {
    id: uid(),
    brand: data.brand || '',
    name: data.name || '',
    country: data.country || '',
    vitola: data.vitola || '',
    length: data.length || null,
    ringGauge: data.ringGauge || null,
    productionYear: data.productionYear || null,
    quantity: Number(data.quantity) || 0,
    purchasePrice: data.purchasePrice != null ? Number(data.purchasePrice) : null,
    purchaseTotal: data.purchaseTotal != null ? Number(data.purchaseTotal) : null,
    purchaseDate: data.purchaseDate || null,
    purchaseLocation: data.purchaseLocation || '',
    humidorId: data.humidorId || db.settings.defaultHumidorId,
    entryDate: data.entryDate || nowISO().slice(0, 10),
    favorite: !!data.favorite,
    rating: data.rating != null ? Number(data.rating) : null,
    notes: data.notes || '',
    photo: data.photo || null,
    createdAt: nowISO(),
    updatedAt: nowISO(),
  };
  db.cigars.unshift(cigar);
  if (cigar.quantity > 0) {
    addMovement({
      cigarId: cigar.id,
      type: 'add',
      quantityChange: cigar.quantity,
      notes: 'Ajout initial',
    });
  }
  persist();
  return cigar;
}

function updateCigar(id, patch) {
  const cigar = getCigar(id);
  if (!cigar) return null;
  Object.assign(cigar, patch, { updatedAt: nowISO() });
  persist();
  return cigar;
}

function deleteCigar(id) {
  db.cigars = db.cigars.filter((c) => c.id !== id);
  db.movements = db.movements.filter((m) => m.cigarId !== id);
  db.tastings = db.tastings.filter((t) => t.cigarId !== id);
  persist();
}

function changeQuantity(id, delta, type) {
  const cigar = getCigar(id);
  if (!cigar) return null;
  const next = Math.max(0, cigar.quantity + delta);
  const applied = next - cigar.quantity;
  cigar.quantity = next;
  cigar.updatedAt = nowISO();
  if (applied !== 0) {
    addMovement({
      cigarId: id,
      type: type || (applied > 0 ? 'add' : 'consume'),
      quantityChange: applied,
    });
  }
  persist();
  return cigar;
}

// ---------------------------------------------------------------------
// Mouvements (historique)
// ---------------------------------------------------------------------

function addMovement(data) {
  const movement = {
    id: uid(),
    cigarId: data.cigarId,
    type: data.type, // 'add' | 'consume' | 'adjust' | 'tasting'
    quantityChange: data.quantityChange || 0,
    date: nowISO(),
    notes: data.notes || '',
  };
  db.movements.unshift(movement);
  persist();
  return movement;
}

function getMovements(limit) {
  return limit ? db.movements.slice(0, limit) : db.movements;
}

// ---------------------------------------------------------------------
// Dégustations
// ---------------------------------------------------------------------

function addTasting(data) {
  const tasting = {
    id: uid(),
    cigarId: data.cigarId,
    date: data.date || nowISO(),
    duration: data.duration || null,
    rating: data.rating != null ? Number(data.rating) : null,
    draw: data.draw || null,
    burn: data.burn || null,
    strength: data.strength || null,
    aromas: data.aromas || [],
    notes: data.notes || '',
  };
  db.tastings.unshift(tasting);
  addMovement({ cigarId: data.cigarId, type: 'tasting', quantityChange: 0, notes: 'Dégustation enregistrée' });
  persist();
  return tasting;
}

function getTastings() {
  return db.tastings;
}

function getTastingsForCigar(cigarId) {
  return db.tastings.filter((t) => t.cigarId === cigarId);
}

// ---------------------------------------------------------------------
// Humidors
// ---------------------------------------------------------------------

function getHumidors() {
  return db.humidors;
}

// ---------------------------------------------------------------------
// Réglages / import-export
// ---------------------------------------------------------------------

function getSettings() {
  return db.settings;
}

function updateSettings(patch) {
  Object.assign(db.settings, patch);
  persist();
}

function exportData() {
  return JSON.stringify(db, null, 2);
}

function importData(json) {
  const parsed = JSON.parse(json);
  db = { ...defaultDB(), ...parsed };
  persist();
}

function resetAll() {
  db = defaultDB();
  persist();
}

export const Storage = {
  getCigars,
  getCigar,
  addCigar,
  updateCigar,
  deleteCigar,
  changeQuantity,
  addMovement,
  getMovements,
  addTasting,
  getTastings,
  getTastingsForCigar,
  getHumidors,
  getSettings,
  updateSettings,
  exportData,
  importData,
  resetAll,
};
