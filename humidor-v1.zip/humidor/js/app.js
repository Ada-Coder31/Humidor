import { Storage } from './storage.js';
import { Icon } from './icons.js';
import { renderHome } from './screens/home.js';
import { renderHumidor } from './screens/humidor.js';
import { renderAddCigar, initAddCigarForm } from './screens/addCigar.js';
import { renderEditCigar, initEditCigarForm } from './screens/editCigar.js';
import { renderDetail } from './screens/detail.js';
import { renderPlaceholder } from './screens/placeholder.js';

const TABS = [
  { id: 'home', label: 'Accueil', icon: 'home' },
  { id: 'humidor', label: 'Humidor', icon: 'humidor' },
  { id: 'add', label: 'Ajouter', icon: 'add' },
  { id: 'journal', label: 'Journal', icon: 'journal' },
  { id: 'stats', label: 'Statistiques', icon: 'stats' },
];

// L'état de nav n'a pas besoin d'être persistant : uniquement en mémoire
// pour la session en cours.
const state = {
  screen: 'home', // home | humidor | add | edit | detail | journal | stats
  humidorQuery: '',
  currentCigarId: null,
};

const appEl = document.getElementById('app');

function screenContent() {
  switch (state.screen) {
    case 'home': return renderHome();
    case 'humidor': return renderHumidor(state);
    case 'add': return renderAddCigar();
    case 'edit': return renderEditCigar(state.currentCigarId);
    case 'detail': return renderDetail(state.currentCigarId);
    case 'journal': return renderPlaceholder({
      title: 'Journal', phase: 'Dégustations',
      subtitle: "Le carnet de dégustation (arômes, notes, tirage, combustion) arrive dans une prochaine version.",
    });
    case 'stats': return renderPlaceholder({
      title: 'Statistiques', phase: 'Analyse de la collection',
      subtitle: "Les statistiques détaillées (origines, marques, valeur) arrivent dans une prochaine version.",
    });
    default: return renderHome();
  }
}

function navBar() {
  // La barre de nav est masquée sur les écrans "fiche" / "édition" pour
  // laisser toute la place au contenu et au bouton retour.
  if (state.screen === 'detail' || state.screen === 'edit') return '';
  const activeTab = state.screen === 'add' ? 'add' : state.screen;
  return `
    <nav class="bottom-nav">
      ${TABS.map((t) => `
        <button class="nav-item ${activeTab === t.id ? 'active' : ''}" data-nav="${t.id}">
          ${Icon[t.icon]}
          <span>${t.label}</span>
          <span class="nav-dot"></span>
        </button>
      `).join('')}
    </nav>
  `;
}

function render() {
  appEl.innerHTML = screenContent() + navBar();
  wireScreenBehaviour();
  window.scrollTo(0, 0);
}

function goTo(screen, extra = {}) {
  state.screen = screen;
  Object.assign(state, extra);
  render();
}

function wireScreenBehaviour() {
  if (state.screen === 'add') {
    initAddCigarForm((cigar) => {
      showToastSheet({
        title: 'Cigare enregistré',
        sub: `${cigar.brand} ${cigar.name} a été ajouté à votre humidor.`,
        actions: [
          { label: 'Voir la fiche', primary: true, action: () => goTo('detail', { currentCigarId: cigar.id }) },
          { label: "Retour à l'accueil", action: () => goTo('home') },
        ],
      });
    });
  }

  if (state.screen === 'edit') {
    initEditCigarForm(state.currentCigarId, (cigarId) => {
      goTo('detail', { currentCigarId: cigarId });
    });
  }

  if (state.screen === 'humidor') {
    const input = document.getElementById('humidor-search');
    if (input) {
      input.addEventListener('input', () => {
        state.humidorQuery = input.value;
        // Ré-affiche uniquement la liste pour garder le focus sur le champ.
        renderHumidorListOnly();
      });
      // Replace le curseur en fin de champ après un re-render partiel.
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
    }
  }
}

function renderHumidorListOnly() {
  const listWrap = appEl.querySelector('.cigar-list, .empty-state');
  if (!listWrap) return;
  const fresh = document.createElement('div');
  fresh.innerHTML = renderHumidor(state);
  const newList = fresh.querySelector('.cigar-list, .empty-state');
  listWrap.replaceWith(newList);
}

function showToastSheet({ title, sub, actions }) {
  const overlay = document.createElement('div');
  overlay.className = 'sheet-overlay';
  overlay.innerHTML = `
    <div class="sheet">
      <div class="sheet-title">${title}</div>
      <div class="sheet-sub">${sub}</div>
      <div class="sheet-actions">
        ${actions.map((a, i) => `<button class="${a.primary ? 'btn-primary' : 'btn-secondary'}" data-sheet-action="${i}">${a.label}</button>`).join('')}
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) { overlay.remove(); return; }
    const btn = e.target.closest('[data-sheet-action]');
    if (btn) {
      overlay.remove();
      actions[Number(btn.dataset.sheetAction)].action();
    }
  });
}

function confirmSheet({ title, sub, confirmLabel, danger, onConfirm }) {
  showToastSheet({
    title, sub,
    actions: [
      { label: confirmLabel, primary: !danger, action: onConfirm },
      { label: 'Annuler', action: () => {} },
    ],
  });
}

// ---------------------------------------------------------------------
// Délégation d'événements globale
// ---------------------------------------------------------------------

document.addEventListener('click', (e) => {
  const navBtn = e.target.closest('[data-nav]');
  if (navBtn) {
    const target = navBtn.dataset.nav;
    if (target === 'detail') {
      goTo('detail', { currentCigarId: navBtn.dataset.cigarId });
    } else if (target === 'add') {
      goTo('add');
    } else {
      goTo(target, target === 'humidor' ? { humidorQuery: '' } : {});
    }
    return;
  }

  const cigarCard = e.target.closest('[data-open-cigar]');
  if (cigarCard) {
    goTo('detail', { currentCigarId: cigarCard.dataset.openCigar });
    return;
  }

  const qtyBtn = e.target.closest('[data-qty-delta]');
  if (qtyBtn) {
    const delta = Number(qtyBtn.dataset.qtyDelta);
    Storage.changeQuantity(state.currentCigarId, delta, delta > 0 ? 'add' : 'consume');
    render();
    return;
  }

  const actionBtn = e.target.closest('[data-action]');
  if (actionBtn) {
    const action = actionBtn.dataset.action;
    if (action === 'edit') {
      goTo('edit', { currentCigarId: state.currentCigarId });
    } else if (action === 'consume') {
      const cigar = Storage.changeQuantity(state.currentCigarId, -1, 'consume');
      render();
      if (cigar) {
        showToastSheet({
          title: 'Cigare consommé',
          sub: `Vous venez de consommer un ${cigar.brand} ${cigar.name}. Stock : ${cigar.quantity + 1} → ${cigar.quantity}.`,
          actions: [
            { label: 'Fermer', primary: true, action: () => {} },
          ],
        });
      }
    } else if (action === 'delete') {
      const cigar = Storage.getCigar(state.currentCigarId);
      confirmSheet({
        title: 'Supprimer ce cigare ?',
        sub: `${cigar.brand} ${cigar.name} et son historique seront définitivement supprimés.`,
        confirmLabel: 'Supprimer',
        danger: true,
        onConfirm: () => {
          Storage.deleteCigar(cigar.id);
          goTo('humidor', { humidorQuery: '' });
        },
      });
    }
  }
});

render();

// ---------------------------------------------------------------------
// Enregistrement du service worker (fonctionnement hors connexion)
// ---------------------------------------------------------------------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch((err) => {
      console.warn('Service worker non enregistré :', err);
    });
  });
}
