import { Storage } from '../storage.js';
import { formatPrice, formatDateTime, collectionValue, totalCigarCount } from '../utils.js';
import { Icon } from '../icons.js';

const MOVEMENT_LABELS = {
  add: (m, cigarName) => `+ ${m.quantityChange} × ${cigarName}`,
  consume: (m, cigarName) => `− ${Math.abs(m.quantityChange)} × ${cigarName}`,
  adjust: (m, cigarName) => `Ajustement · ${cigarName}`,
  tasting: (m, cigarName) => `Dégustation · ${cigarName}`,
};

export function renderHome() {
  const cigars = Storage.getCigars();
  const settings = Storage.getSettings();
  const humidors = Storage.getHumidors();
  const capacity = humidors[0]?.capacity || 100;
  const total = totalCigarCount(cigars);
  const refs = cigars.length;
  const value = collectionValue(cigars);
  const pct = capacity > 0 ? Math.min(100, Math.round((total / capacity) * 100)) : 0;

  const movements = Storage.getMovements(6).map((m) => {
    const cigar = Storage.getCigar(m.cigarId);
    const cigarName = cigar ? `${cigar.brand} ${cigar.name}`.trim() : 'Cigare supprimé';
    const label = (MOVEMENT_LABELS[m.type] || MOVEMENT_LABELS.adjust)(m, cigarName);
    const isAdd = m.quantityChange > 0;
    return `
      <div class="movement-row">
        <div class="movement-icon ${isAdd ? 'add' : m.quantityChange < 0 ? 'remove' : ''}">
          ${m.quantityChange !== 0 ? (isAdd ? '+' : '−') : '•'}
        </div>
        <div class="movement-text">
          <div>${label}</div>
          <div class="movement-date">${formatDateTime(m.date)}</div>
        </div>
      </div>`;
  }).join('');

  return `
    <div class="screen">
      <span class="eyebrow">Cave personnelle</span>
      <h1 class="screen-title">Mon Humidor</h1>
      <p class="screen-subtitle">Ma collection personnelle</p>

      <div class="stat-grid">
        <div class="stat-card">
          <div class="stat-label">Cigares</div>
          <div class="stat-value mono">${total}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Références</div>
          <div class="stat-value mono">${refs}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Valeur</div>
          <div class="stat-value mono">${formatPrice(value, settings.currency)}</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Capacité</div>
          <div class="stat-value mono">${total} / ${capacity}</div>
          <div class="capacity-bar"><div class="capacity-bar-fill" style="width:${pct}%"></div></div>
          <div class="stat-sub">${pct}% rempli</div>
        </div>
      </div>

      <div class="section-title">Derniers mouvements</div>
      ${movements ? `<div class="movement-list">${movements}</div>` : `
        <div class="empty-state">
          <div class="empty-title">L'humidor est vide, pour l'instant</div>
          <div class="empty-sub">Ajoutez votre premier cigare pour commencer.</div>
        </div>`}

      <div style="margin-top:24px;">
        <button class="btn-primary" data-nav="add">${Icon.add} Ajouter un cigare</button>
      </div>
    </div>
  `;
}
