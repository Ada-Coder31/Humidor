import { Storage } from '../storage.js';

export function renderAddCigar() {
  const humidors = Storage.getHumidors();
  const today = new Date().toISOString().slice(0, 10);

  const humidorOptions = humidors.map((h) => `<option value="${h.id}">${h.name}</option>`).join('');

  return `
    <div class="screen">
      <span class="eyebrow">Nouvelle référence</span>
      <h1 class="screen-title">Ajouter un cigare</h1>
      <p class="screen-subtitle">Seuls la marque et le nom sont obligatoires.</p>

      <form id="add-cigar-form">
        <div class="form-section-title">Identification</div>
        <div class="form-group">
          <label for="f-brand">Marque *</label>
          <input id="f-brand" name="brand" type="text" placeholder="Cohiba" required>
        </div>
        <div class="form-group">
          <label for="f-name">Nom / référence *</label>
          <input id="f-name" name="name" type="text" placeholder="Robusto" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="f-vitola">Vitola</label>
            <input id="f-vitola" name="vitola" type="text" placeholder="Robusto">
          </div>
          <div class="form-group">
            <label for="f-country">Pays</label>
            <input id="f-country" name="country" type="text" placeholder="Cuba">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="f-length">Longueur (cm)</label>
            <input id="f-length" name="length" type="number" step="0.1" placeholder="12.7">
          </div>
          <div class="form-group">
            <label for="f-ring">Ring gauge</label>
            <input id="f-ring" name="ringGauge" type="number" placeholder="50">
          </div>
        </div>
        <div class="form-group">
          <label for="f-year">Année de production</label>
          <input id="f-year" name="productionYear" type="number" placeholder="2023">
        </div>

        <div class="form-section-title">Stock</div>
        <div class="form-group">
          <label for="f-quantity">Quantité</label>
          <input id="f-quantity" name="quantity" type="number" min="0" value="1">
        </div>

        <div class="form-section-title">Achat</div>
        <div class="form-row">
          <div class="form-group">
            <label for="f-price-unit">Prix unitaire</label>
            <input id="f-price-unit" name="purchasePrice" type="number" step="0.01" placeholder="24.00">
          </div>
          <div class="form-group">
            <label for="f-price-total">Prix total</label>
            <input id="f-price-total" name="purchaseTotal" type="number" step="0.01" placeholder="Calculé automatiquement" readonly>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="f-purchase-date">Date d'achat</label>
            <input id="f-purchase-date" name="purchaseDate" type="date" value="${today}">
          </div>
          <div class="form-group">
            <label for="f-purchase-location">Lieu d'achat</label>
            <input id="f-purchase-location" name="purchaseLocation" type="text" placeholder="Buraliste, voyage...">
          </div>
        </div>

        <div class="form-section-title">Humidor</div>
        <div class="form-row">
          <div class="form-group">
            <label for="f-entry-date">Date d'entrée</label>
            <input id="f-entry-date" name="entryDate" type="date" value="${today}">
          </div>
          <div class="form-group">
            <label for="f-humidor">Humidor</label>
            <select id="f-humidor" name="humidorId">${humidorOptions}</select>
          </div>
        </div>

        <div class="form-section-title">Informations personnelles</div>
        <div class="form-group">
          <div class="toggle-row">
            <span>Favori</span>
            <div class="switch" id="f-favorite-switch"></div>
          </div>
          <input type="hidden" id="f-favorite" name="favorite" value="">
        </div>
        <div class="form-group">
          <label>Note personnelle</label>
          <div class="rating-picker" id="f-rating-picker"></div>
          <input type="hidden" id="f-rating" name="rating" value="">
        </div>
        <div class="form-group">
          <label for="f-notes">Commentaires</label>
          <textarea id="f-notes" name="notes" rows="3" placeholder="Vos impressions, à quelle occasion..."></textarea>
        </div>
        <div class="form-group">
          <label for="f-photo">Photo</label>
          <input id="f-photo" name="photo" type="file" accept="image/*">
        </div>

        <div style="margin-top:8px;">
          <button type="submit" class="btn-primary">Enregistrer</button>
        </div>
      </form>
    </div>
  `;
}

export function initAddCigarForm(onSaved) {
  const form = document.getElementById('add-cigar-form');
  if (!form) return;

  // Note personnelle (1 à 10)
  const ratingPicker = document.getElementById('f-rating-picker');
  const ratingInput = document.getElementById('f-rating');
  for (let i = 1; i <= 10; i++) {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'rating-dot';
    dot.textContent = i;
    dot.addEventListener('click', () => {
      const already = ratingInput.value === String(i);
      ratingInput.value = already ? '' : String(i);
      [...ratingPicker.children].forEach((c) => c.classList.remove('selected'));
      if (!already) dot.classList.add('selected');
    });
    ratingPicker.appendChild(dot);
  }

  // Favori (interrupteur)
  const favSwitch = document.getElementById('f-favorite-switch');
  const favInput = document.getElementById('f-favorite');
  favSwitch.addEventListener('click', () => {
    const isOn = favSwitch.classList.toggle('on');
    favInput.value = isOn ? '1' : '';
  });

  // Prix total = prix unitaire × quantité
  const priceUnit = document.getElementById('f-price-unit');
  const priceTotal = document.getElementById('f-price-total');
  const quantity = document.getElementById('f-quantity');
  function recomputeTotal() {
    const unit = parseFloat(priceUnit.value);
    const qty = parseFloat(quantity.value);
    if (!isNaN(unit) && !isNaN(qty)) {
      priceTotal.value = (unit * qty).toFixed(2);
    } else {
      priceTotal.value = '';
    }
  }
  priceUnit.addEventListener('input', recomputeTotal);
  quantity.addEventListener('input', recomputeTotal);

  // Photo -> stockée en base64 (simple pour une V1 sans serveur)
  let photoData = null;
  const photoInput = document.getElementById('f-photo');
  photoInput.addEventListener('change', () => {
    const file = photoInput.files[0];
    if (!file) { photoData = null; return; }
    const reader = new FileReader();
    reader.onload = () => { photoData = reader.result; };
    reader.readAsDataURL(file);
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const cigar = Storage.addCigar({
      brand: fd.get('brand'),
      name: fd.get('name'),
      vitola: fd.get('vitola'),
      country: fd.get('country'),
      length: fd.get('length') || null,
      ringGauge: fd.get('ringGauge') || null,
      productionYear: fd.get('productionYear') || null,
      quantity: fd.get('quantity') || 0,
      purchasePrice: fd.get('purchasePrice') || null,
      purchaseTotal: fd.get('purchaseTotal') || null,
      purchaseDate: fd.get('purchaseDate') || null,
      purchaseLocation: fd.get('purchaseLocation'),
      entryDate: fd.get('entryDate') || null,
      humidorId: fd.get('humidorId'),
      favorite: !!fd.get('favorite'),
      rating: fd.get('rating') || null,
      notes: fd.get('notes'),
      photo: photoData,
    });
    onSaved(cigar);
  });
}
