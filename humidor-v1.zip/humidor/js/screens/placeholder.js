export function renderPlaceholder({ title, subtitle, phase }) {
  return `
    <div class="screen">
      <span class="eyebrow">${phase}</span>
      <h1 class="screen-title">${title}</h1>
      <div class="placeholder-screen">
        <div class="band-ring">✦</div>
        <div class="empty-title">Bientôt disponible</div>
        <div class="empty-sub">${subtitle}</div>
      </div>
    </div>
  `;
}
