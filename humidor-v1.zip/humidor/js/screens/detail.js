import { Storage } from '../storage.js';
import { formatPrice, formatDate, computeAge, countryFlag, cigarValue, initials } from '../utils.js';

export function renderDetail(cigarId) {
  const cigar = Storage.getCigar(cigarId);
  const settings = Storage.getSettings();
  if (!cigar) {
    return `<div class="screen"><div class="empty-state"><div class="empty-title">Ce cigare n'existe plus</div></div></div>`;
  }

  const age = computeAge(cigar.entryDate);
  const value = cigarValue(cigar);

  return `
    <div class="top-bar">
      <button class="back-btn" data-nav="humidor">${'<'}</button>
      <span class="top-bar-title">Fiche cigare</span>
    </div>
    <div class="screen" style="padding-top:6px;">
      <div class="detail-hero">
        <div class="detail-photo band-ring">
          ${cigar.photo ? `<img src="${cigar.photo}" alt="">` : initials(cigar.brand || cigar.name)}
        </div>
        <span class="eyebrow">${cigar.brand || 'Sans marque'}</span>
        <h1 class="screen-title">${cigar.name || 'Sans nom'}</h1>
        <div class="detail-country">${countryFlag(cigar.country)} ${cigar.country || '—'}</div>
        ${cigar.vitola ? `<div class="detail-vitola">${cigar.vitola}</div>` : ''}
      </div>

      <div class="stock-control">
        <button class="stock-btn" data-qty-delta="-1">−</button>
        <div class="stock-value mono">${cigar.quantity}</div>
        <button class="stock-btn" data-qty-delta="1">+</button>
      </div>
      ${cigar.quantity === 0 ? `<div style="text-align:center;margin-top:-14px;margin-bottom:14px;"><span class="tag-oos">Rupture de stock</span></div>` : ''}

      <div class="section-title">Informations</div>
      <div class="info-grid">
        <div class="info-item"><div class="info-label">Longueur</div><div class="info-value">${cigar.length ? cigar.length + ' cm' : '—'}</div></div>
        <div class="info-item"><div class="info-label">Ring gauge</div><div class="info-value">${cigar.ringGauge || '—'}</div></div>
        <div class="info-item"><div class="info-label">Année</div><div class="info-value">${cigar.productionYear || '—'}</div></div>
        <div class="info-item"><div class="info-label">Date d'achat</div><div class="info-value">${formatDate(cigar.purchaseDate)}</div></div>
        <div class="info-item"><div class="info-label">Lieu d'achat</div><div class="info-value">${cigar.purchaseLocation || '—'}</div></div>
        <div class="info-item"><div class="info-label">Prix unitaire</div><div class="info-value">${formatPrice(cigar.purchasePrice, settings.currency)}</div></div>
        <div class="info-item"><div class="info-label">Valeur du stock</div><div class="info-value">${formatPrice(value, settings.currency)}</div></div>
        <div class="info-item"><div class="info-label">Entré le</div><div class="info-value">${formatDate(cigar.entryDate)}</div></div>
      </div>

      <div class="section-title">Vieillissement</div>
      <div class="info-item">
        <div class="info-label">Âge dans l'humidor</div>
        <div class="info-value" style="font-family:var(--font-display);font-size:18px;">${age || '—'}</div>
      </div>

      ${(cigar.rating || cigar.notes) ? `
        <div class="section-title">Mon avis</div>
        ${cigar.rating ? `<div class="info-item" style="display:inline-block;"><div class="info-label">Note</div><div class="info-value">★ ${cigar.rating}/10</div></div>` : ''}
        ${cigar.notes ? `<div class="notes-block">${escapeHtml(cigar.notes)}</div>` : ''}
      ` : ''}

      <div class="action-grid">
        <button class="btn-secondary" data-action="edit">Modifier</button>
        <button class="btn-secondary" data-action="consume" ${cigar.quantity === 0 ? 'disabled' : ''}>Consommer 1</button>
        <button class="btn-danger" data-action="delete" style="grid-column: 1 / -1;">Supprimer</button>
      </div>
    </div>
  `;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
