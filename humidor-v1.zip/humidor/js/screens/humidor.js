import { Storage } from '../storage.js';
import { formatPrice, countryFlag, initials } from '../utils.js';
import { Icon } from '../icons.js';

export function renderHumidor(state) {
  const query = (state.humidorQuery || '').trim().toLowerCase();
  const settings = Storage.getSettings();
  let cigars = Storage.getCigars();

  if (query) {
    cigars = cigars.filter((c) => {
      const haystack = [c.brand, c.name, c.vitola, c.country, c.notes].join(' ').toLowerCase();
      return haystack.includes(query);
    });
  }

  const cards = cigars.map((c) => `
    <div class="cigar-card ${c.quantity === 0 ? 'out-of-stock' : ''}" data-open-cigar="${c.id}">
      <div class="cigar-thumb">
        ${c.photo ? `<img src="${c.photo}" alt="">` : initials(c.brand || c.name)}
      </div>
      <div class="cigar-info">
        <div class="cigar-brand">${c.brand || 'Sans marque'}</div>
        <div class="cigar-name">${c.name || 'Sans nom'}</div>
        <div class="cigar-meta">
          <span>${countryFlag(c.country)} ${c.country || '—'}</span>
          ${c.vitola ? `<span>${c.vitola}</span>` : ''}
          ${c.quantity === 0 ? '<span class="tag-oos">Rupture de stock</span>' : ''}
        </div>
      </div>
      <div class="cigar-side">
        <div class="cigar-qty">× ${c.quantity}</div>
        <div class="cigar-price">${c.purchasePrice != null ? formatPrice(c.purchasePrice, settings.currency) + ' / u' : '—'}</div>
        ${c.rating ? `<div class="cigar-rating">★ ${c.rating}/10</div>` : ''}
        ${c.favorite ? `<div class="cigar-fav">${Icon.star}</div>` : ''}
      </div>
    </div>
  `).join('');

  return `
    <div class="screen">
      <span class="eyebrow">Collection complète</span>
      <h1 class="screen-title">Humidor</h1>

      <div class="search-bar">
        <input type="text" id="humidor-search" placeholder="Rechercher un cigare..." value="${query ? escapeAttr(state.humidorQuery) : ''}">
        <button class="filter-btn" disabled title="Bientôt disponible">Filtrer</button>
      </div>

      ${cigars.length ? `<div class="cigar-list">${cards}</div>` : `
        <div class="empty-state">
          <div class="empty-title">${query ? 'Aucun résultat' : 'Aucun cigare pour le moment'}</div>
          <div class="empty-sub">${query ? "Essayez un autre mot-clé." : 'Ajoutez votre premier cigare depuis l\'onglet "Ajouter".'}</div>
        </div>`}
    </div>
  `;
}

function escapeAttr(str) {
  return String(str).replace(/"/g, '&quot;');
}
