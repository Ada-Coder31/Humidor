import { Storage } from '../storage.js';

export function renderEditCigar(cigarId) {
  const c = Storage.getCigar(cigarId);
  if (!c) return `<div class="screen"><div class="empty-state"><div class="empty-title">Ce cigare n'existe plus</div></div></div>`;

  const humidors = Storage.getHumidors();
  const humidorOptions = humidors.map((h) =>
    `<option value="${h.id}" ${h.id === c.humidorId ? 'selected' : ''}>${h.name}</option>`).join('');

  return `
    <div class="top-bar">
      <button class="back-btn" data-nav="detail" data-cigar-id="${c.id}">${'<'}</button>
      <span class="top-bar-title">Modifier</span>
    </div>
    <div class="screen" style="padding-top:6px;">
      <form id="edit-cigar-form">
        <div class="form-section-title">Identification</div>
        <div class="form-group"><label>Marque *</label><input name="brand" type="text" value="${attr(c.brand)}" required></div>
        <div class="form-group"><label>Nom / référence *</label><input name="name" type="text" value="${attr(c.name)}" required></div>
        <div class="form-row">
          <div class="form-group"><label>Vitola</label><input name="vitola" type="text" value="${attr(c.vitola)}"></div>
          <div class="form-group"><label>Pays</label><input name="country" type="text" value="${attr(c.country)}"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Longueur (cm)</label><input name="length" type="number" step="0.1" value="${attr(c.length)}"></div>
          <div class="form-group"><label>Ring gauge</label><input name="ringGauge" type="number" value="${attr(c.ringGauge)}"></div>
        </div>
        <div class="form-group"><label>Année de production</label><input name="productionYear" type="number" value="${attr(c.productionYear)}"></div>

        <div class="form-section-title">Achat</div>
        <div class="form-row">
          <div class="form-group"><label>Prix unitaire</label><input id="e-price-unit" name="purchasePrice" type="number" step="0.01" value="${attr(c.purchasePrice)}"></div>
          <div class="form-group"><label>Lieu d'achat</label><input name="purchaseLocation" type="text" value="${attr(c.purchaseLocation)}"></div>
        </div>
        <div class="form-group"><label>Date d'achat</label><input name="purchaseDate" type="date" value="${attr(c.purchaseDate)}"></div>

        <div class="form-section-title">Humidor</div>
        <div class="form-row">
          <div class="form-group"><label>Date d'entrée</label><input name="entryDate" type="date" value="${attr(c.entryDate)}"></div>
          <div class="form-group"><label>Humidor</label><select name="humidorId">${humidorOptions}</select></div>
        </div>

        <div class="form-section-title">Informations personnelles</div>
        <div class="form-group">
          <div class="toggle-row">
            <span>Favori</span>
            <div class="switch ${c.favorite ? 'on' : ''}" id="e-favorite-switch"></div>
          </div>
          <input type="hidden" id="e-favorite" name="favorite" value="${c.favorite ? '1' : ''}">
        </div>
        <div class="form-group">
          <label>Note personnelle</label>
          <div class="rating-picker" id="e-rating-picker"></div>
          <input type="hidden" id="e-rating" name="rating" value="${attr(c.rating)}">
        </div>
        <div class="form-group"><label>Commentaires</label><textarea name="notes" rows="3">${attr(c.notes)}</textarea></div>

        <div style="margin-top:8px;">
          <button type="submit" class="btn-primary">Enregistrer les modifications</button>
        </div>
      </form>
    </div>
  `;
}

function attr(v) {
  if (v == null) return '';
  return String(v).replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

export function initEditCigarForm(cigarId, onSaved) {
  const form = document.getElementById('edit-cigar-form');
  if (!form) return;
  const c = Storage.getCigar(cigarId);

  const ratingPicker = document.getElementById('e-rating-picker');
  const ratingInput = document.getElementById('e-rating');
  for (let i = 1; i <= 10; i++) {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'rating-dot' + (String(c.rating) === String(i) ? ' selected' : '');
    dot.textContent = i;
    dot.addEventListener('click', () => {
      const already = ratingInput.value === String(i);
      ratingInput.value = already ? '' : String(i);
      [...ratingPicker.children].forEach((el) => el.classList.remove('selected'));
      if (!already) dot.classList.add('selected');
    });
    ratingPicker.appendChild(dot);
  }

  const favSwitch = document.getElementById('e-favorite-switch');
  const favInput = document.getElementById('e-favorite');
  favSwitch.addEventListener('click', () => {
    const isOn = favSwitch.classList.toggle('on');
    favInput.value = isOn ? '1' : '';
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    Storage.updateCigar(cigarId, {
      brand: fd.get('brand'),
      name: fd.get('name'),
      vitola: fd.get('vitola'),
      country: fd.get('country'),
      length: fd.get('length') || null,
      ringGauge: fd.get('ringGauge') || null,
      productionYear: fd.get('productionYear') || null,
      purchasePrice: fd.get('purchasePrice') || null,
      purchaseDate: fd.get('purchaseDate') || null,
      purchaseLocation: fd.get('purchaseLocation'),
      entryDate: fd.get('entryDate') || null,
      humidorId: fd.get('humidorId'),
      favorite: !!fd.get('favorite'),
      rating: fd.get('rating') || null,
      notes: fd.get('notes'),
    });
    onSaved(cigarId);
  });
}
